# import unittest
# from main import SignUp
#
#
# class Unittesting(unittest.TestCase):
#     def test_SHU(self):
#         self.assertTrue(SignUp('test@sacredheart.edu', 'password'))
#         #tests for @sacredheart.edu email / asserting true
#
#     def test_MailSHU(self):
#         self.assertTrue(SignUp('test@mail.sacredheart.edu', 'password'))
#         #tests for @ mail.sacredheart.edu email / asserting true
#
#     def test_fairfield(self):
#         self.assertFalse(SignUp('test@Fairfieldstinks.gov', 'password'))
#         #tests for @Fairfieldstinks.gov email / asserting false

import unittest
from main import checkCreds, getLogin


#from Auth2 import *


class test(unittest.TestCase):
    def test_Creds(self):
        email, password = getLogin()
        self.assertFalse(checkCreds(email, password))

    # def test_CheckEmail_Invalid(self):
    #     self.assertFalse(CheckEmail("test@FairfieldUniversity.edu"))
    #
    # def test_CheckPass(self):
    #     self.assertTrue(CheckPass(password))
