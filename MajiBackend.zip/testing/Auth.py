class Auth():
    def readDB(self, email, password):
        dataBase = open("database.txt", 'r')
        for line in dataBase:
            index += 1
            if email in line:
                if password in line:
                    return True
                else:
                    return False
            else:
                return False

    def getLogin(self):
        email = str(input("Email: "))
        password = str(input("Password: "))
        return email, password

    def regLogin(self):
        print("Please Supply an email with domain '@sacredheart.edu' or '@mail.sacredheart.edu'!")
        print('Please choose a password longer than 12 characters!')
        email, password = Auth.getLogin()
        # if email.test_CheckEmail() == True:
        #     if password.test_CheckPassword() == True:
        #         dataBase.write(email, '|', password)
        #     else:
        #         print('Error: Password')
        # else:
        #     print('Error: Email')


    def checkInput(self):
        email, password = Auth.getLogin()
        domain = email.split('@')[1]
        if domain == 'mail.sacredheart.edu' or domain == 'sacredheart.edu':
            print("Create New Account.")
            print(password)
            return True
        else:
            print("Failure to Create New Account.")
            print(password)
            return False