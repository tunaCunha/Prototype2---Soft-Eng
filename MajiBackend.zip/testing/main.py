# from Unittest import *
# def SignUp(email, password):
#     if email == 'test@mail.sacredheart.edu' or email == 'test@sacredheart.edu':
#         # ends with @mail..
#         print(email, password)
#         print('Account created successfully.')
#         return True
#     else:
#         print('Account creation failed')
#         return False
#
# def main():
#     myunittest = Unittesting()
#     ##myunittest.test_MailSHU()
#     myunittest.test_SHU()
#     ##myunittest.test_fairfield()
#
from Unittest import *

def readDBEmail(email):
    index = 0
    dataBase = open("database.txt", 'r')
    for line in dataBase:
        index += 1
        if email in line:
            return True
        else:
            print("We're sorry, that email is incorrect.")
            return False


def readDBPass(email, password):
    index = 0
    dataBase = open("database.txt", 'r')
    for line in dataBase:
        index += 1
        if email in line:
            index += 1
            if password in line:
                print('Email and password accepted. Welcome back!')
                return True
            else:
                print("We're sorry, that password is incorrect.")
                return False
        else:
            pass


def getLogin():
    print("Please enter your email and password...")
    email = str(input("Email: "))
    password = str(input("Password: "))
    return email, password


def Register():
    print("Please enter an email and password that you would like to register.")
    email = str(input("Email: "))
    password = str(input("Password: "))
    domain = email.split('@')[1]
    if domain == 'mail.sacredheart.edu' or domain == 'sacredheart.edu':
        dataBase = open("database.txt", 'a')
        dataBase.write('\n' + email + '\n' + password)
        dataBase.close
        print("Email Accepted. Thank you for joining us!")
        #add to db
    else:
        print("Failure to Create New Account: Invalid email address.")


def checkCreds(email, password):
    domain = email.split('@')[1]
    if domain == 'mail.sacredheart.edu' or domain == 'sacredheart.edu':
        if readDBEmail(email):
            readDBPass(email, password)
        else:
            return False
    else:
        print("We're sorry, that email is not supported.")
        return False


def main():
    kG = 'y'
    testMe = test()
    while(kG == 'y'):
        print('Welcome to MagiNotes *Back-end*. Would you like to: \n1) Login \n2) Register an Account. \n3) Quit')
        choice = int(input('> '))
        if choice == 1:
            testMe.test_Creds()
        elif choice == 2:
            Register()
        elif choice == 3:
            kG = 'n'
        else:
            pass


if __name__ == "__main__":
    main()